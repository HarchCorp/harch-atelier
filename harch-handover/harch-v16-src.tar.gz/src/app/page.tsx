"use client";

import * as React from "react";
import { DashboardShell } from "@/components/dashboard/dashboard-shell";
import { RiskMatrix } from "@/components/dataviz/risk-matrix";
import { ShareOfVoice } from "@/components/dataviz/share-of-voice";
import { MediaCoverageChart } from "@/components/dataviz/media-coverage-chart";
import { SentimentTrend } from "@/components/dataviz/sentiment-trend";
import { RiskPillars } from "@/components/dataviz/risk-pillars";
import { TopSources } from "@/components/dataviz/top-sources";
import { GeoDistribution } from "@/components/dataviz/geo-distribution";
import { RiskTrendTimeline } from "@/components/dataviz/risk-trend-timeline";
import { RiskEventsTable } from "@/components/dashboard/risk-events-table";
import { WatchlistSignals } from "@/components/dashboard/watchlist-signals";
import { RiskEventDrawer } from "@/components/dashboard/risk-event-drawer";
import { CommandPalette, useCommandPalette } from "@/components/dashboard/command-palette";
import {
  KeyboardShortcuts,
  useKeyboardShortcuts,
} from "@/components/dashboard/keyboard-shortcuts";
import type { AccountType, RiskEvent, AlertItem } from "@/lib/mock-data";
import { riskEvents } from "@/lib/mock-data";

const metaByAccount: Record<AccountType, { title: string; description: string }> = {
  admin: {
    title: "Operations Console",
    description: "Full-spectrum risk intelligence across every monitored entity and pillar.",
  },
  trader: {
    title: "Signal Desk",
    description: "Live risk signals with coverage context for HarchCorp positions.",
  },
  legal: {
    title: "Legal & Regulatory Monitor",
    description: "Regulatory exposure, matters, and hold-notice activity across entities.",
  },
  market: {
    title: "Market Intelligence",
    description: "Sentiment, share of voice, and coverage analytics for the IR desk.",
  },
  self: {
    title: "My Watch",
    description: "Personalized monitoring for your tracked entities and saved alerts.",
  },
  pr: {
    title: "Communications Console",
    description: "Reputation, sentiment, and share-of-voice analytics for comms teams.",
  },
};

/** Enterprise grid — market / admin / pr / legal / self. */
function EnterpriseGrid({ onSelect, onSelectEvent }: { onSelect: (e: RiskEvent) => void; onSelectEvent: (eventId: string) => void }) {
  return (
    <div className="flex flex-col gap-5">
      {/* Row 0 — full-width risk trend timeline */}
      <RiskTrendTimeline onSelectEvent={onSelectEvent} />
      {/* Row 1 */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <RiskMatrix onSelect={onSelect} />
        <MediaCoverageChart />
      </div>
      {/* Row 2 */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <ShareOfVoice />
        <SentimentTrend />
      </div>
      {/* Row 3 — analytical widgets */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <RiskPillars />
        <div className="xl:col-span-2">
          <TopSources />
        </div>
      </div>
      {/* Row 4 — geo + events */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <GeoDistribution />
        <div className="xl:col-span-2">
          <RiskEventsTable onSelect={onSelect} />
        </div>
      </div>
    </div>
  );
}

/** Trader desk — watchlist on top, then matrix + coverage + geo. */
function TraderView({ onSelect, onSelectEvent }: { onSelect: (e: RiskEvent) => void; onSelectEvent: (eventId: string) => void }) {
  return (
    <div className="flex flex-col gap-5">
      <WatchlistSignals />
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <RiskMatrix onSelect={onSelect} />
        <MediaCoverageChart />
      </div>
      <RiskTrendTimeline onSelectEvent={onSelectEvent} />
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <RiskPillars />
        <div className="xl:col-span-2">
          <TopSources />
        </div>
      </div>
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-3">
        <GeoDistribution />
        <div className="xl:col-span-2">
          <RiskEventsTable onSelect={onSelect} />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const [accountType, setAccountType] = React.useState<AccountType>("market");
  const [selectedEvent, setSelectedEvent] = React.useState<RiskEvent | null>(null);
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const [helpOpen, setHelpOpen] = React.useState(false);

  const palette = useCommandPalette();
  useKeyboardShortcuts(() => setHelpOpen((v) => !v));

  const handleSelect = React.useCallback((e: RiskEvent) => {
    setSelectedEvent(e);
    setDrawerOpen(true);
  }, []);

  const handleSelectById = React.useCallback((eventId: string) => {
    const ev = riskEvents.find((e) => e.id === eventId);
    if (ev) {
      setSelectedEvent(ev);
      setDrawerOpen(true);
    }
  }, []);

  const handleOpenAlert = React.useCallback((a: AlertItem) => {
    if (!a.eventId) return;
    const ev = riskEvents.find((e) => e.id === a.eventId);
    if (ev) {
      setSelectedEvent(ev);
      setDrawerOpen(true);
    }
  }, []);

  const meta = metaByAccount[accountType];

  return (
    <DashboardShell
      accountType={accountType}
      onAccountTypeChange={setAccountType}
      onOpenPalette={palette.toggle}
      onOpenAlert={handleOpenAlert}
      title={meta.title}
      description={meta.description}
    >
      {accountType === "trader" ? (
        <TraderView onSelect={handleSelect} onSelectEvent={handleSelectById} />
      ) : (
        <EnterpriseGrid onSelect={handleSelect} onSelectEvent={handleSelectById} />
      )}
      <RiskEventDrawer
        event={selectedEvent}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
      />
      <CommandPalette
        open={palette.open}
        onOpenChange={palette.setOpen}
        accountType={accountType}
        onAccountTypeChange={setAccountType}
        onSelectEvent={handleSelect}
      />
      <KeyboardShortcuts open={helpOpen} onOpenChange={setHelpOpen} />
    </DashboardShell>
  );
}
