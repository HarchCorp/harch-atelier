"use client";

import * as React from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  ExternalLink,
  Globe,
  Users2,
  Newspaper,
  Sparkles,
  CheckCircle2,
  ArrowUpRight,
  Bell,
  ShieldAlert,
  Clock,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import {
  getArticlesFor,
  getEntitiesFor,
  sentimentColor,
  severityColor,
  type RiskEvent,
} from "@/lib/mock-data";
import { useRiskStore, useActionState, type ActionState } from "@/lib/risk-store";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface RiskEventDrawerProps {
  event: RiskEvent | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const pillarTint: Record<string, string> = {
  Regulatory: "bg-violet-50 text-violet-700 ring-violet-200",
  Cyber: "bg-cyan-50 text-cyan-700 ring-cyan-200",
  Financial: "bg-sky-50 text-sky-700 ring-sky-200",
  ESG: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  Geopolitical: "bg-amber-50 text-amber-700 ring-amber-200",
  Reputational: "bg-rose-50 text-rose-700 ring-rose-200",
};

const tierLabel: Record<string, string> = {
  tier1: "Tier 1 · Legacy",
  tier2: "Tier 2 · Trade",
  tier3: "Tier 3 · Long-tail",
};

function formatRelative(iso: string): string {
  const now = new Date();
  const d = new Date(iso);
  const diffMs = now.getTime() - d.getTime();
  const diffH = Math.round(diffMs / 3_600_000);
  if (diffH < 1) return "just now";
  if (diffH < 24) return `${diffH}h ago`;
  const diffD = Math.round(diffH / 24);
  return `${diffD}d ago`;
}

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleString("en-US", {
    month: "short",
    day: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const languageLabel: Record<string, string> = {
  en: "English",
  fr: "French",
  de: "German",
  es: "Spanish",
  zh: "Chinese",
};

function GlmSummary({ event }: { event: RiskEvent }) {
  // Deterministic GLM-4 style synthesis (no network call).
  const tone =
    event.sentiment === "negative"
      ? "adverse"
      : event.sentiment === "positive"
        ? "favorable"
        : "neutral";
  const intensity =
    event.severity === "critical"
      ? "elevated and accelerating"
      : event.severity === "high"
        ? "elevated"
        : event.severity === "medium"
          ? "moderate"
          : "low-grade";
  const reach = event.articles * 4_200;
  return (
    <div className="rounded-lg border border-slate-200 bg-gradient-to-br from-slate-50 to-white p-3">
      <div className="flex items-center gap-1.5">
        <Sparkles className="h-3.5 w-3.5 text-violet-600" />
        <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
          GLM-4 Synthesis
        </span>
        <Badge variant="secondary" className="ml-auto h-4 px-1.5 text-[9px] font-medium">
          auto-generated
        </Badge>
      </div>
      <p className="mt-2 text-[12px] leading-relaxed text-slate-700">
        Coverage of the <span className="font-semibold text-slate-900">{event.pillar.toLowerCase()}</span> signal{" "}
        <span className="font-medium text-slate-900">&ldquo;{event.title}&rdquo;</span> is currently{" "}
        <span className="font-semibold text-slate-900">{tone}</span> with{" "}
        <span className="font-semibold text-slate-900">{intensity}</span> media velocity. An estimated{" "}
        <span className="tabular font-semibold text-slate-900">{reach.toLocaleString()}</span> readers have been
        exposed across <span className="tabular font-semibold text-slate-900">{event.articles}</span> deduplicated
        articles. Top-tier outlets dominate the narrative frame; recommend a coordinated holding statement and a
        48-hour sentiment re-baseline.
      </p>
    </div>
  );
}

function ArticleRow({ a }: { a: import("@/lib/mock-data").Article }) {
  const snt = sentimentColor[a.sentiment];
  return (
    <a
      href={a.url}
      onClick={(e) => e.preventDefault()}
      className="group flex items-start gap-3 rounded-lg border border-transparent px-2 py-2 transition-colors hover:border-slate-200 hover:bg-slate-50"
    >
      <span className={cn("mt-1 h-2 w-2 shrink-0 rounded-full", snt.dot)} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="truncate text-[12px] font-medium text-slate-800 group-hover:text-slate-900">
            {a.headline}
          </span>
          <ExternalLink className="h-3 w-3 shrink-0 text-slate-300 opacity-0 transition-opacity group-hover:opacity-100" />
        </div>
        <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-slate-400">
          <span className="font-medium text-slate-500">{a.source}</span>
          <span className="rounded bg-slate-100 px-1 py-px text-[9px] font-medium text-slate-500">
            {tierLabel[a.tier]}
          </span>
          <span className="flex items-center gap-0.5">
            <Globe className="h-2.5 w-2.5" />
            {languageLabel[a.language]}
          </span>
          <span className="flex items-center gap-0.5">
            <Clock className="h-2.5 w-2.5" />
            {formatRelative(a.publishedAt)}
          </span>
        </div>
      </div>
      <div className="shrink-0 text-right">
        <div className="tabular text-[11px] font-semibold text-slate-700">
          {(a.reach / 1000).toFixed(0)}k
        </div>
        <div className="text-[9px] uppercase tracking-wide text-slate-400">reach</div>
      </div>
    </a>
  );
}

export function RiskEventDrawer({ event, open, onOpenChange }: RiskEventDrawerProps) {
  const articles = React.useMemo(() => (event ? getArticlesFor(event) : []), [event]);
  const entities = React.useMemo(
    () => (event ? getEntitiesFor(event, event.title.length) : []),
    [event],
  );
  const sc = event ? severityColor[event.severity] : null;
  const snt = event ? sentimentColor[event.sentiment] : null;

  // Shared action state from the Zustand store (syncs with table + alerts).
  const actionState = useActionState(event?.id);
  const setAction = useRiskStore((s) => s.setAction);

  const fireAction = React.useCallback(
    (action: ActionState) => {
      if (!event) return;
      setAction(event.id, action);
      const label =
        action === "acknowledged"
          ? "Acknowledged"
          : action === "escalated"
            ? "Escalated"
            : action === "watching"
              ? "Added to watchlist"
              : "";
      const verb =
        action === "acknowledged"
          ? "acknowledged"
          : action === "escalated"
            ? "escalated to the incident channel"
            : action === "watching"
              ? "added to your watchlist"
              : "";
      toast.success(`${label}: ${event.title}`, {
        description: `Event ${event.id} has been ${verb}.`,
      });
    },
    [event, setAction],
  );

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="harch-scroll w-full overflow-y-auto border-slate-200 bg-white p-0 sm:max-w-[560px]"
      >
        {event && sc && snt ? (
          <div className="flex h-full flex-col">
            {/* Header band */}
            <div className={cn("border-b px-5 pb-4 pt-4", sc.bg)}>
              <SheetHeader className="space-y-0 p-0">
                <div className="flex items-center gap-2">
                  <span
                    className={cn(
                      "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ring-1 ring-inset",
                      sc.bg,
                      sc.text,
                      sc.ring,
                    )}
                  >
                    <span className={cn("h-1.5 w-1.5 rounded-full", sc.dot)} />
                    {event.severity}
                  </span>
                  <span
                    className={cn(
                      "inline-flex rounded px-1.5 py-0.5 text-[10px] font-medium ring-1 ring-inset",
                      pillarTint[event.pillar],
                    )}
                  >
                    {event.pillar}
                  </span>
                  <span className="ml-auto tabular text-[10px] font-medium text-slate-500">
                    {event.id}
                  </span>
                </div>
                <SheetTitle className="text-left text-[16px] font-bold leading-snug text-slate-900">
                  {event.title}
                </SheetTitle>
                <SheetDescription className="sr-only">
                  Risk event detail: {event.title}
                </SheetDescription>
              </SheetHeader>

              {/* Quick stats grid */}
              <div className="mt-3 grid grid-cols-3 gap-2">
                <div className="rounded-md bg-white/70 px-2.5 py-1.5">
                  <div className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">Articles</div>
                  <div className="tabular text-[16px] font-bold text-slate-900">{event.articles}</div>
                </div>
                <div className="rounded-md bg-white/70 px-2.5 py-1.5">
                  <div className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">Sentiment</div>
                  <div className={cn("flex items-center gap-1 text-[13px] font-semibold capitalize", snt.text)}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", snt.dot)} />
                    {event.sentiment}
                  </div>
                </div>
                <div className="rounded-md bg-white/70 px-2.5 py-1.5">
                  <div className="text-[9px] font-semibold uppercase tracking-wide text-slate-500">Detected</div>
                  <div className="tabular text-[12px] font-semibold text-slate-700">
                    {formatRelative(event.date)}
                  </div>
                </div>
              </div>
            </div>

            {/* Scrollable body */}
            <div className="harch-scroll flex-1 overflow-y-auto px-5 py-4">
              {/* GLM summary */}
              <GlmSummary event={event} />

              {/* Affected entities */}
              <section className="mt-4">
                <div className="flex items-center gap-1.5">
                  <Users2 className="h-3.5 w-3.5 text-slate-400" />
                  <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    Affected entities
                  </h4>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {entities.map((e) => (
                    <span
                      key={e}
                      className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-slate-50 px-2 py-1 text-[11px] font-medium text-slate-700"
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-slate-400" />
                      {e}
                    </span>
                  ))}
                </div>
              </section>

              <Separator className="my-4 bg-slate-100" />

              {/* Articles list */}
              <section>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Newspaper className="h-3.5 w-3.5 text-slate-400" />
                    <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                      Source articles
                    </h4>
                  </div>
                  <span className="tabular text-[10px] text-slate-400">
                    {articles.length} of {event.articles}
                  </span>
                </div>
                <div className="mt-2 space-y-0.5">
                  {articles.map((a) => (
                    <ArticleRow key={a.id} a={a} />
                  ))}
                </div>
              </section>
            </div>

            {/* Footer actions */}
            <div className="border-t border-slate-200 bg-slate-50/60 px-5 py-3">
              <div className="flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  onClick={() => fireAction("acknowledged")}
                  disabled={actionState === "acknowledged"}
                  className={cn(
                    "h-8 gap-1.5",
                    actionState === "acknowledged"
                      ? "bg-emerald-600 text-white hover:bg-emerald-600"
                      : "bg-slate-900 text-white hover:bg-slate-800",
                  )}
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  {actionState === "acknowledged" ? "Acknowledged" : "Acknowledge"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => fireAction("escalated")}
                  disabled={actionState === "escalated"}
                  className={cn(
                    "h-8 gap-1.5 border-slate-200 bg-white",
                    actionState === "escalated" && "border-amber-300 bg-amber-50 text-amber-700 hover:bg-amber-50",
                  )}
                >
                  <ArrowUpRight className="h-3.5 w-3.5" />
                  {actionState === "escalated" ? "Escalated" : "Escalate"}
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => fireAction("watching")}
                  disabled={actionState === "watching"}
                  className={cn(
                    "h-8 gap-1.5 border-slate-200 bg-white",
                    actionState === "watching" && "border-sky-300 bg-sky-50 text-sky-700 hover:bg-sky-50",
                  )}
                >
                  <Bell className="h-3.5 w-3.5" />
                  {actionState === "watching" ? "Watching" : "Watch"}
                </Button>
                <span className="ml-auto flex items-center gap-1 text-[10px] text-slate-400">
                  <ShieldAlert className="h-3 w-3" />
                  Last GLM pass {formatDateTime(event.date)}
                </span>
              </div>
            </div>
          </div>
        ) : null}
      </SheetContent>
    </Sheet>
  );
}
