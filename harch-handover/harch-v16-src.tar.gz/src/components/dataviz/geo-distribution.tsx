"use client";

import * as React from "react";
import { ChartCard } from "./chart-card";
import { geoRegions, type RiskPillar } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

const pillarDot: Record<RiskPillar, string> = {
  Regulatory: "bg-violet-500",
  Cyber: "bg-cyan-500",
  Financial: "bg-sky-500",
  ESG: "bg-emerald-500",
  Geopolitical: "bg-amber-500",
  Reputational: "bg-rose-500",
};

/** intensity 0-100 → heat color (slate → amber → rose) */
function heatColor(intensity: number): string {
  if (intensity >= 70) return "#e11d48"; // rose-600
  if (intensity >= 55) return "#ea580c"; // orange-600
  if (intensity >= 40) return "#d97706"; // amber-600
  if (intensity >= 25) return "#64748b"; // slate-500
  return "#cbd5e1"; // slate-300
}

function heatOpacity(intensity: number): number {
  return 0.18 + (intensity / 100) * 0.55;
}

const skewLabel = (s: number): string => (s === 0 ? "neutral" : s > 0 ? `+${s}` : `${s}`);

/** Simplified abstract world-strip — 5 stacked horizontal bands, one per region. */
function WorldStrip() {
  return (
    <svg viewBox="0 0 320 110" className="h-[110px] w-full" role="img" aria-label="Regional signal intensity map">
      <defs>
        <pattern id="grid" width="8" height="8" patternUnits="userSpaceOnUse">
          <path d="M 8 0 L 0 0 0 8" fill="none" stroke="#f1f5f9" strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect x="0" y="0" width="320" height="110" fill="url(#grid)" />
      {/* North America — top-left band */}
      <rect x="8" y="6" width="92" height="22" rx="3" fill={heatColor(geoRegions[0].intensity)} fillOpacity={heatOpacity(geoRegions[0].intensity)} />
      <text x="14" y="21" fontSize="9" fontWeight="700" fill="#475569">NA</text>
      {/* Europe — top-middle band */}
      <rect x="120" y="6" width="80" height="22" rx="3" fill={heatColor(geoRegions[1].intensity)} fillOpacity={heatOpacity(geoRegions[1].intensity)} />
      <text x="126" y="21" fontSize="9" fontWeight="700" fill="#475569">EU</text>
      {/* APAC — top-right band */}
      <rect x="216" y="6" width="96" height="22" rx="3" fill={heatColor(geoRegions[2].intensity)} fillOpacity={heatOpacity(geoRegions[2].intensity)} />
      <text x="222" y="21" fontSize="9" fontWeight="700" fill="#475569">APAC</text>
      {/* MEA — middle band */}
      <rect x="120" y="44" width="96" height="22" rx="3" fill={heatColor(geoRegions[3].intensity)} fillOpacity={heatOpacity(geoRegions[3].intensity)} />
      <text x="126" y="59" fontSize="9" fontWeight="700" fill="#475569">MEA</text>
      {/* LATAM — bottom band */}
      <rect x="40" y="82" width="92" height="22" rx="3" fill={heatColor(geoRegions[4].intensity)} fillOpacity={heatOpacity(geoRegions[4].intensity)} />
      <text x="46" y="97" fontSize="9" fontWeight="700" fill="#475569">LATAM</text>
      {/* connection dots for visual interest */}
      {[
        { x: 100, y: 17 },
        { x: 200, y: 17 },
        { x: 264, y: 17 },
      ].map((p, i) => (
        <g key={i}>
          <circle cx={p.x} cy={p.y} r="2.5" fill="#fff" stroke="#e2e8f0" strokeWidth="1" />
          <circle cx={p.x} cy={p.y} r="1.2" fill="#0f172a" />
        </g>
      ))}
    </svg>
  );
}

export function GeoDistribution() {
  const totalSignals = geoRegions.reduce((s, r) => s + r.signals, 0);
  const maxIntensity = Math.max(...geoRegions.map((r) => r.intensity));
  return (
    <ChartCard
      id="geo"
      title="Geographic Distribution"
      subtitle="Signal intensity by region · 30d"
      action={
        <div className="flex items-center gap-1.5 text-[9px] text-slate-400">
          <span>low</span>
          <span className="flex gap-0.5">
            {["#cbd5e1", "#64748b", "#d97706", "#ea580c", "#e11d48"].map((c) => (
              <span key={c} className="h-2 w-2 rounded-sm" style={{ backgroundColor: c }} />
            ))}
          </span>
          <span>high</span>
        </div>
      }
      footer={
        <span>
          <span className="tabular font-semibold text-slate-700">{totalSignals}</span> signals across{" "}
          <span className="tabular font-semibold text-slate-700">{geoRegions.length}</span> regions ·
          hottest: <span className="font-semibold text-slate-700">{geoRegions[0].name}</span>
        </span>
      }
    >
      <WorldStrip />
      <div className="mt-3 space-y-1.5">
        {geoRegions.map((r) => (
          <div
            key={r.code}
            className="group flex items-center gap-2 rounded-md px-1.5 py-1 transition-colors hover:bg-slate-50"
          >
            <span
              className="h-2 w-2 shrink-0 rounded-full"
              style={{ backgroundColor: heatColor(r.intensity) }}
            />
            <span className="w-28 shrink-0 truncate text-[11px] font-medium text-slate-700">{r.name}</span>
            <div className="relative h-1.5 flex-1 overflow-hidden rounded-full bg-slate-100">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${(r.intensity / maxIntensity) * 100}%`,
                  backgroundColor: heatColor(r.intensity),
                }}
              />
            </div>
            <span className="tabular w-6 shrink-0 text-right text-[10px] font-semibold text-slate-700">{r.signals}</span>
            <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", pillarDot[r.topPillar])} title={`Top pillar: ${r.topPillar}`} />
            <span
              className={cn(
                "tabular w-10 shrink-0 text-right text-[10px] font-medium",
                r.sentimentSkew > 0 ? "text-emerald-700" : r.sentimentSkew < 0 ? "text-rose-700" : "text-slate-500",
              )}
            >
              {skewLabel(r.sentimentSkew)}
            </span>
          </div>
        ))}
      </div>
    </ChartCard>
  );
}
