"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import { getArticlesFor, type AlertStatus, type RiskEvent, type RiskPillar, type Severity } from "@/lib/mock-data";

/**
 * Shared risk-event action state.
 *
 * Keeps a map of eventId → ActionState so the drawer, the RiskEventsTable,
 * and the AlertsPopover all render the same status. Actions (acknowledge /
 * escalate / watch) are dispatched here and every subscriber re-renders.
 *
 * `actions` and `readAlerts` are persisted to localStorage so acknowledged /
 * escalated state survives page reloads. `filters` are session-only.
 */

export type ActionState = "pending" | "acknowledged" | "escalated" | "watching";

export interface FilterState {
  pillar: RiskPillar | "all";
  severity: Severity | "all";
  status: ActionState | "all";
  source: string | "all";
  query: string;
}

export interface SavedView {
  id: string;
  name: string;
  filters: FilterState;
  createdAt: number;
}

interface RiskState {
  /** eventId → action state */
  actions: Record<string, ActionState>;
  /** alertId → read flag */
  readAlerts: Record<string, boolean>;
  /** session-only filters (not persisted) */
  filters: FilterState;
  /** selected eventIds for bulk operations */
  selected: Set<string>;
  /** named filter presets (persisted) */
  savedViews: SavedView[];

  setAction: (eventId: string, state: ActionState) => void;
  getAction: (eventId: string) => ActionState;

  markAlertRead: (alertId: string) => void;
  markAllAlertsRead: (alertIds: string[]) => void;
  acknowledgeAll: (alertIds: string[], eventIds: string[]) => void;
  isAlertRead: (alertId: string) => boolean;

  setFilter: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void;
  resetFilters: () => void;

  toggleSelected: (eventId: string) => void;
  setSelected: (eventIds: string[]) => void;
  clearSelected: () => void;
  bulkAcknowledge: () => void;
  bulkEscalate: () => void;

  saveView: (name: string) => void;
  loadView: (id: string) => void;
  deleteView: (id: string) => void;

  /** Wipe all persisted + session state (reset workspace). */
  clearAll: () => void;
}

const defaultFilters: FilterState = {
  pillar: "all",
  severity: "all",
  status: "all",
  source: "all",
  query: "",
};

export const useRiskStore = create<RiskState>()(
  persist(
    (set, get) => ({
      actions: {},
      readAlerts: {},
      filters: { ...defaultFilters },
      selected: new Set<string>(),
      savedViews: [],

      setAction: (eventId, state) =>
        set((s) => ({
          actions: { ...s.actions, [eventId]: state },
        })),

      getAction: (eventId) => get().actions[eventId] ?? "pending",

      markAlertRead: (alertId) =>
        set((s) => ({
          readAlerts: { ...s.readAlerts, [alertId]: true },
        })),

      markAllAlertsRead: (alertIds) =>
        set((s) => {
          const next = { ...s.readAlerts };
          for (const id of alertIds) next[id] = true;
          return { readAlerts: next };
        }),

      acknowledgeAll: (alertIds, eventIds) =>
        set((s) => {
          const nextActions = { ...s.actions };
          const nextReads = { ...s.readAlerts };
          for (const id of eventIds) nextActions[id] = "acknowledged";
          for (const id of alertIds) nextReads[id] = true;
          return { actions: nextActions, readAlerts: nextReads };
        }),

      isAlertRead: (alertId) => get().readAlerts[alertId] === true,

      setFilter: (key, value) =>
        set((s) => ({ filters: { ...s.filters, [key]: value } })),

      resetFilters: () => set({ filters: { ...defaultFilters } }),

      toggleSelected: (eventId) =>
        set((s) => {
          const next = new Set(s.selected);
          if (next.has(eventId)) next.delete(eventId);
          else next.add(eventId);
          return { selected: next };
        }),

      setSelected: (eventIds) => set({ selected: new Set(eventIds) }),

      clearSelected: () => set({ selected: new Set<string>() }),

      bulkAcknowledge: () =>
        set((s) => {
          if (s.selected.size === 0) return s;
          const nextActions = { ...s.actions };
          for (const id of s.selected) nextActions[id] = "acknowledged";
          return { actions: nextActions, selected: new Set<string>() };
        }),

      bulkEscalate: () =>
        set((s) => {
          if (s.selected.size === 0) return s;
          const nextActions = { ...s.actions };
          for (const id of s.selected) nextActions[id] = "escalated";
          return { actions: nextActions, selected: new Set<string>() };
        }),

      saveView: (name) =>
        set((s) => {
          const view: SavedView = {
            id: `view-${Date.now().toString(36)}`,
            name: name.trim() || `View ${s.savedViews.length + 1}`,
            filters: { ...s.filters },
            createdAt: Date.now(),
          };
          return { savedViews: [...s.savedViews, view] };
        }),

      loadView: (id) =>
        set((s) => {
          const view = s.savedViews.find((v) => v.id === id);
          if (!view) return s;
          return { filters: { ...view.filters }, selected: new Set<string>() };
        }),

      deleteView: (id) =>
        set((s) => ({
          savedViews: s.savedViews.filter((v) => v.id !== id),
        })),

      clearAll: () =>
        set({
          actions: {},
          readAlerts: {},
          filters: { ...defaultFilters },
          selected: new Set<string>(),
          savedViews: [],
        }),
    }),
    {
      name: "harch-risk-store",
      storage: createJSONStorage(() => localStorage),
      // Persist actions + readAlerts + savedViews. Filters + selected are session-only.
      partialize: (s) => ({
        actions: s.actions,
        readAlerts: s.readAlerts,
        savedViews: s.savedViews,
      }),
      // Skip SSR/hydration mismatch: the store initializes empty on the server
      // and rehydrates on the client. Components read the live value after mount.
      skipHydration: false,
    },
  ),
);

/** Convenience selector hook for a single event's action state. */
export function useActionState(eventId: string | undefined): ActionState {
  return useRiskStore((s) => (eventId ? s.actions[eventId] ?? "pending" : "pending"));
}

/** Status badge metadata shared by table + drawer + alerts. */
export const actionStateMeta: Record<
  ActionState,
  { label: string; chip: string; dot: string }
> = {
  pending: { label: "Pending", chip: "bg-slate-100 text-slate-500", dot: "bg-slate-400" },
  acknowledged: { label: "Acknowledged", chip: "bg-emerald-50 text-emerald-700", dot: "bg-emerald-500" },
  escalated: { label: "Escalated", chip: "bg-amber-50 text-amber-700", dot: "bg-amber-500" },
  watching: { label: "Watching", chip: "bg-sky-50 text-sky-700", dot: "bg-sky-500" },
};

/** Map an ActionState to an AlertStatus for the popover. */
export function actionToAlertStatus(action: ActionState): AlertStatus {
  if (action === "acknowledged") return "acknowledged";
  if (action === "escalated") return "escalated";
  return "new";
}

/** Filter risk events by the current filter state. */
export function filterRiskEvents(
  events: RiskEvent[],
  filters: FilterState,
  actions: Record<string, ActionState>,
): RiskEvent[] {
  const q = filters.query.trim().toLowerCase();
  return events.filter((e) => {
    if (filters.pillar !== "all" && e.pillar !== filters.pillar) return false;
    if (filters.severity !== "all" && e.severity !== filters.severity) return false;
    if (filters.status !== "all") {
      const st = actions[e.id] ?? "pending";
      if (st !== filters.status) return false;
    }
    if (filters.source !== "all") {
      // An event matches a source if any of its articles came from that outlet.
      const arts = getArticlesFor(e);
      if (!arts.some((a) => a.source === filters.source)) return false;
    }
    if (q) {
      const hay = `${e.title} ${e.id} ${e.pillar} ${e.severity}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}
